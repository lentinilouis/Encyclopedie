//Point de départ pour le projt encyclopedie
import 'package:flutter/material.dart';

void main() => runApp(MyApp());

String txttitre = "Encyclopedie";
String txtboby =
    "L’Acadie est généralement considérée comme une région nord-américaine où résident environ 500 000 Acadiens et Acadiennes. L'Acadie comprend grosso modo le nord et l'est de la province canadienne du Nouveau-Brunswick ainsi que des localités et des régions plus isolées au Québec et sur l'Île-du-Prince-Édouard et en Nouvelle-Écosse ainsi que le nord-ouest du Maine aux États-Unis. La communauté francophone de Terre-Neuve-et-Labrador, bien qu'ayant une origine différente des Acadiens, est parfois incluse dans cette définition. D'autres définitions, faisant presque toutes allusion à un territoire, comprennent en général la Louisiane – les Cadiens. La question des frontières de l'Acadie est donc fondamentale mais seules celles de la Louisiane sont reconnues. En fait, selon un certain point de vue, l'Acadie serait donc une nation sans reconnaissance explicite.L'Acadie historique, colonie de la Nouvelle-France, est fondée en 1604 – sur des territoires amérindiens habités depuis 11 millénaires – et peuplée à partir de l'Ouest de la France. La population de l'Acadie comprenait des membres de la confédération Wabanaki et des descendants d'émigrés de la France. Les deux communautés se sont mariées, ce qui a donné lieu à une partie importante de la population de l'Acadie d'être Métis. Conquise en 1713 par le royaume de Grande-Bretagne, elle subit le Grand Dérangement, dont la Déportation des Acadiens de 1755 à 1763, et son territoire est morcelé. De retour d'exil, les Acadiens subissent des lois discriminatoires. La renaissance acadienne, dans laquelle est impliquée le clergé, leur permet toutefois de redécouvrir leur histoire et leur culture. Ils acceptent mal la Confédération canadienne de 1867. Des symboles et des institutions sont créés dès la 1re Convention nationale acadienne de 1881. Les Acadiens sont durement touchés par la Grande Dépression et participent activement aux deux guerres mondiales. La communauté néo-brunswikoise fait figure de chef de file et la seconde moitié du xxe siècle est une période contestataire, marquée par le gain de plusieurs droits et libertés.L'exode rural et l'anglicisation influencent toujours la démographie de l'Acadie. Le rejet de l'assimilation a d'ailleurs une incidence importante sur la politique acadienne. L'Acadie n'a toutefois pas d'organisation politique propre, excepté au niveau local et dans certains domaines comme la santé et l'éducation, tandis que la Société nationale de l'Acadie en est la représentante officielle. L'économie de l'Acadie ne repose plus uniquement sur des activités traditionnelles comme la pêche et est en croissance depuis la fin du xxe siècle. La culture de l'Acadie, fruit d'une longue tradition orale, est mise en valeur depuis les années 1960. L'Université de Moncton, qui a joué un rôle important dans son épanouissement, est également le principal établissement d'enseignement et de recherche. La population dispose en effet d'un vaste réseau de services publics de langue française, quoique peu accessibles dans certaines localités. L'Acadie nouvelle et Radio-Canada Acadie sont les principaux médias. Les liens entre les différentes régions et la diaspora restent forts et sont favorisés par des événements comme le Congrès mondial acadien et les Jeux de l'Acadie.";

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: txttitre,
      home: Scaffold(
        appBar: AppBar(
          title: Text(txttitre),
        ),
        body: Container(
          color: Colors.black,
          child: Column(children: <Widget>[
            Container(
                color: Colors.black, child: Image.asset('assets/acadie.png')),
            Column(
              children: [
                Container(
                    alignment: Alignment.topLeft,
                    child: Text(
                      'Acadie ',
                      textAlign: TextAlign.left,
                      style: TextStyle(
                          fontStyle: FontStyle.italic,
                          color: Colors.white10,
                          fontSize: 30),
                    )),
                Container(
                  alignment: Alignment.bottomLeft,
                  child: Text(
                    'Article labellisé du jour',
                    textAlign: TextAlign.start,
                    style: TextStyle(color: Colors.grey, fontSize: 20),
                  ),
                ),
                Container(
                  alignment: Alignment.bottomLeft,
                  child: Text(
                    ' _______',
                    textAlign: TextAlign.start,
                    style: TextStyle(color: Colors.grey[400], fontSize: 20),
                  ),
                ),
              ],
            ),
            Row(
              children: [
                Container(
                  alignment: Alignment.bottomLeft,
                  child: Text(
                    "Article connexe : Mi'kma'ki. ",
                    textAlign: TextAlign.start,
                    style: TextStyle(color: Colors.white, fontSize: 20),
                  ),
                ),
                Container(
                  alignment: Alignment.centerRight,
                  child: Icon(
                    Icons.edit,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
            Container(
              alignment: Alignment.bottomLeft,
              child: Text(
                txtboby,
                textAlign: TextAlign.start,
                style: TextStyle(color: Colors.white, fontSize: 20),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
